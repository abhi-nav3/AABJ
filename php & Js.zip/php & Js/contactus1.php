<!DOCTYPE html>
<html>
<head>
<title>Contach Us</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body {
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('510.jpg');

	font-family: Arial, Helvetica, sans-serif;
}
* {
	box-sizing: border-box;
}

label {
	color: black;
}

input[type=text], textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

.container {
	margin: auto;
	width: 500px;
  border-radius: 7px;
  background-color: cornsilk;
  padding: 20px;
}

button {
	border: 0px;
	background-color: green;
	color: white;
	border-radius: 7px;
	padding: 13px;
}

button:hover {
	background-color: darkgreen;
}

h2 {
	color: white;
}

</style>

</head>

<body>
<center><h2>Contact Us</h2></center>
<div class="container">
  <form action="contactus2.php" method="post">

    <label for="fname">Name</label>
    <input type="text" name="name" placeholder="Full name.." required>

    <label for="fname">Email</label>
    <input type="text" name="email" placeholder="E-mail.." required>

    <label for="fname">Subject</label>
    <input type="text" name="subject" placeholder="Subject" required>

    <textarea name="message" placeholder="Write something.." style="height:100px" required></textarea>

    <button type="submit" name="submit">Send Mail</button>

  </form>
</div>
</body>
</html>