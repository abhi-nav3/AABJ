<?php 
  session_start();
  include_once "chatappconfig.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: chatapplogin.php");
  }
?>
<?php include_once "chatappheader.php"; ?>


<body>
  <div class="wrapper">
    <button style="margin: 10px; border-radius: 10px; border-style: none; background-color: orange;"><a href="front.php" style="font-size: 16px; margin: 13px; color: green"><i class="fa fa-home"> Home</i></a></button>
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>
          <img src="chatappimages/<?php echo $row['img']; ?>" alt="">
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
            <p><?php echo $row['status']; ?></p>
          </div>
        </div>
        <a href="chatapplogout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
      </header>
      <div class="search">
        <span class="text">Select an user to start chat</span>
        <input type="text" placeholder="Enter name to search...">
        <button><i class="fas fa-search"></i></button>
      </div>
      <div class="users-list">
  
      </div>
    </section>
  </div>

  <script src="chatappusers.js"></script>

</body>
</html>
