<?php 

if (isset($_POST['submit'])) {
	$name=$_POST['name'];
	$emailFrom=$_POST['email'];
	$subject=$_POST['subject'];
	$message=$_POST['message'];

	$to = "nav8abhi@gmail.com";

	if (mail($to, $subject, $message, $emailFrom)) {

		echo '<script>alert("Mail Sent")</script>';

		header("Location: contactus1.php");
	}	
}

?>